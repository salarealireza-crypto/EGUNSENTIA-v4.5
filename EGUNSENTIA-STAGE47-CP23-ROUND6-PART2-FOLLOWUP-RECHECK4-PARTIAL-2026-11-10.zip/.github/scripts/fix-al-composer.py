from pathlib import Path

play_path = Path("src/lib/game/play.ts")
if not play_path.is_file():
    raise SystemExit("Refusing to patch: src/lib/game/play.ts is missing")

play = play_path.read_text(encoding="utf-8")

# Keep the previously installed busy-state repair idempotent.
marker = "// Always release the composer after a failed provider/server request too."
if marker not in play:
    old = '''  } catch (err) {
    console.error("[play]", err);
    useGame.getState().setError("The line to the Hall went dead.");
    useGame.getState().setFailedAction(text);
    useGame.getState().markLastPlayerFailed(true);
    useGame.getState().pushNote("The line to the Hall went dead. Try the action again.");
  }
}

/** Generate another narrative answer'''
    new = '''  } catch (err) {
    console.error("[play]", err);
    useGame.getState().setError("The line to the Hall went dead.");
    useGame.getState().setFailedAction(text);
    useGame.getState().markLastPlayerFailed(true);
    useGame.getState().pushNote("The line to the Hall went dead. Try the action again.");
  } finally {
    // Always release the composer after a failed provider/server request too.
    // Otherwise busy stays true and the player cannot send or retry another action.
    useGame.getState().setBusy(false);
  }
}

/** Generate another narrative answer'''
    count = play.count(old)
    if count != 1:
        raise SystemExit(f"Refusing composer patch: expected one target block, found {count}")
    play = play.replace(old, new, 1)

# The pre-request state-building catch previously set an internal error but
# neither rendered it nor added a visible chat note.
old_prepare = '''  } catch {
    useGame.getState().setBusy(false);
    useGame.getState().setError("The current campaign state could not be compressed safely. Your saved campaign remains unchanged.");
    useGame.getState().setFailedAction(text);
    useGame.getState().markLastPlayerFailed(true);
    return;
  }'''
new_prepare = '''  } catch (err) {
    console.error("[play] failed to prepare AL context", err);
    const message = "The current campaign state could not be prepared for AL. Your saved campaign remains unchanged.";
    useGame.getState().setBusy(false);
    useGame.getState().setError(message);
    useGame.getState().setFailedAction(text);
    useGame.getState().markLastPlayerFailed(true);
    useGame.getState().pushNote(message);
    return;
  }'''
if new_prepare not in play:
    count = play.count(old_prepare)
    if count != 1:
        raise SystemExit(f"Refusing AL preparation diagnostic patch: expected one target block, found {count}")
    play = play.replace(old_prepare, new_prepare, 1)

play_path.write_text(play, encoding="utf-8")

scene_path = Path("src/components/game/SceneView.tsx")
if not scene_path.is_file():
    raise SystemExit("Refusing to patch: src/components/game/SceneView.tsx is missing")

scene = scene_path.read_text(encoding="utf-8")
busy_line = '  const busy = useGame((s) => s.busy);\n'
error_line = '  const error = useGame((s) => s.error);\n'
if error_line not in scene:
    if scene.count(busy_line) != 1:
        raise SystemExit("Refusing UI patch: could not uniquely locate busy selector")
    scene = scene.replace(busy_line, busy_line + error_line, 1)

notice_line = '        {notice ? <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-accent-soft">{notice}</p> : null}\n'
error_ui = '        {error ? <p role="alert" className="rounded-[10px] border border-accent/40 bg-bg-subtle px-3 py-2 font-mono text-[11px] leading-relaxed text-accent-soft">{error}</p> : null}\n'
if error_ui not in scene:
    if scene.count(notice_line) != 1:
        raise SystemExit("Refusing UI patch: could not uniquely locate notice display")
    scene = scene.replace(notice_line, error_ui + notice_line, 1)

scene_path.write_text(scene, encoding="utf-8")
print("AL diagnostics applied: preparation failures are visible in the chat and error state is rendered in the Hall.")
