from pathlib import Path

play = Path("src/lib/game/play.ts")
if not play.is_file():
    raise SystemExit("Refusing to patch: src/lib/game/play.ts is missing")

source = play.read_text(encoding="utf-8")
old = '''    useGame.getState().setError(message);
    useGame.getState().setFailedAction(text);'''
new = '''    useGame.getState().setError(message);
    // SceneView renders notice, not the internal error field. Surface the
    // precise client-side preflight failure so the player is never left with
    // a silent failed turn.
    useGame.getState().setNotice(message);
    useGame.getState().setFailedAction(text);'''

if new in source:
    print("Already applied: show the AL preflight error in the game UI")
else:
    count = source.count(old)
    if count != 1:
        raise SystemExit(
            "Refusing to patch play.ts: expected exactly one preflight error block, "
            f"found {count}"
        )
    source = source.replace(old, new, 1)
    play.write_text(source, encoding="utf-8")
    print("Applied: show the AL preflight error in the game UI")
